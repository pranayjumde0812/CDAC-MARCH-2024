﻿namespace OnlineShoppingWeb
{
    public class ProductRepository
    {
    }
}
