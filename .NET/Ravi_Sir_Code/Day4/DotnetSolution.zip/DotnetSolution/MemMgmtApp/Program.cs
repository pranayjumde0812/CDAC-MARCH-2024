﻿

using MemMgmtApp;

using (Product p1 = new Product("Gerbera", 12))
{

}
   
