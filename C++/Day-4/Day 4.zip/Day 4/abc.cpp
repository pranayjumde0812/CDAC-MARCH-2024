#include<iostream>
#include<string>
using namespace std;
/*Library Catalog with Books and Journals:
Problem Statement: Build a library catalog system. 
Create a base class LibraryItem with properties like title and author. 
Then, derive classes like Book and Journal, each with their unique properties. 
Implement methods to check out and return items in the derived classes.
*/  
  class LibraryItem{
    string author ;
    string title ;
   
  LibraryItem(string author , string title){
    this->author=author;
    this->title=title;
  }    
    

  }


int main(){











    return 0 ;
}