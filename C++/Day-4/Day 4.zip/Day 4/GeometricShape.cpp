/*Geometric Shapes with Polymorphism:
Problem Statement: Extend the shape hierarchy example by implementing polymorphism. 
Define a base class Shape with methods to calculate area and perimeter. Then, create derived classes 
like Circle, Rectangle, and Triangle, 
each with its own implementation of these methods.*/

#include<iostream>
using namespace std;

class Shape{

    public:
    void calArea()
    {
       
    }

};

int main()
{
    return 0;
}

 